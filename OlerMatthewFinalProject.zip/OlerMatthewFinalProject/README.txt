This folder contains the final project submission for Matthew Oler for SDEV140 ("OlerMatthewFinalProject")

This folder also contains the user manual ("User Manual")

As well as the link to the GitHub repository: https://github.com/Matthew20337282019/SDEV140Final

Validation Testing:
For this program I had problems with things not going as planned. It was difficult to have an exact data set
to test, simply pressing buttons within the tkinter window and unexpected results arising. I was unable to
resolve some of these issues, this is reflected with documentation within the source code.

