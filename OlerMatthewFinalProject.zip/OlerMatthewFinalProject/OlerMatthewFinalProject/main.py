import tkinter as tk

def firstAction():
    rootWindow = tk.Tk()
    rootWindow.title('Welcome to the Sub Builder!')
    rootWindow.geometry("750x500")

    start_lbl = tk.Label(rootWindow, text="Welcome to the submarine sandwich builder! Press 'start' to begin!", bg="Yellow")
    start_btn = tk.Button(rootWindow, text="Start", bg="green", command=start)

    start_lbl.place(x=175,y=150)
    start_btn.place(x=340,y=200)

    rootWindow.mainloop()

def start():
    global startUp, rootWindow
    startUp = True
    rootWindow.destroy()
    mainWindow = tk.Tk()
    mainWindow.title('Sub Builder')
    mainWindow.geometry("750x500")
    mainWindow.mainloop

startUp = False
while startUp ==  False:
    firstAction


